const { SlashCommandBuilder } = require('discord.js');

module.exports = {

  data: new SlashCommandBuilder()

    .setName('anonreply')

    .setDescription('Send an anonymous message, optionally as a reply')

    .addStringOption(option =>

      option.setName('text')

        .setDescription('The message to send anonymously')

        .setRequired(true))

    .addStringOption(option =>

      option.setName('message_id')

        .setDescription('Optional: ID of the message to reply to')

        .setRequired(false)),

  async execute(interaction) {

    const text = interaction.options.getString('text');

    const messageId = interaction.options.getString('message_id');

    try {

      // Try to fetch the target message if message_id is provided

      const channel = interaction.channel;

      let msgPayload = { content: text };

      if (messageId) {

        try {

          const targetMsg = await channel.messages.fetch(messageId);

          msgPayload = {

            content: text,

            reply: {

              messageReference: targetMsg.id,

              failIfNotExists: false

            }

          };

        } catch (e) {

          // If message fetch fails, ignore and send normally

        }

      }

      // Send the anonymous message

      await channel.send(msgPayload);

      // Immediately delete the user's interaction (no trace)

      await interaction.deferReply({ ephemeral: true });

      await interaction.deleteReply(); // This removes the ephemeral reply entirely

    } catch (err) {

      console.error('Anon command failed:', err);

      // Don't even reply with an error — total stealth mode

    }

  }

};