const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dm')
    .setDescription('Send a custom DM to up to 3 users and a role')

    // 🟢 Required option first!
    .addStringOption(option =>
      option.setName('message')
        .setDescription('The message to send in DMs')
        .setRequired(true))

    // 🔵 Optional ones below
    .addUserOption(option =>
      option.setName('user1')
        .setDescription('First user')
        .setRequired(false))
    .addUserOption(option =>
      option.setName('user2')
        .setDescription('Second user')
        .setRequired(false))
    .addUserOption(option =>
      option.setName('user3')
        .setDescription('Third user')
        .setRequired(false))
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('Role to DM')
        .setRequired(false)),

  async execute(interaction) {
    const message = interaction.options.getString('message');
    const user1 = interaction.options.getUser('user1');
    const user2 = interaction.options.getUser('user2');
    const user3 = interaction.options.getUser('user3');
    const role = interaction.options.getRole('role');

    const recipients = [user1, user2, user3].filter(u => u);

    if (role) {
      const roleMembers = interaction.guild.members.cache.filter(member =>
        member.roles.cache.has(role.id)
      );
      recipients.push(...roleMembers.map(m => m.user));
    }

    const sent = [];
    for (const user of recipients) {
      try {
        await user.send(message);
        sent.push(user.username);
      } catch (err) {
        console.log(`❌ Couldn't DM ${user.username}`);
      }
    }

    await interaction.reply({
      content: `✅ Message sent to: ${sent.join(', ') || 'nobody'}`,
      ephemeral: true
    });
  }
};