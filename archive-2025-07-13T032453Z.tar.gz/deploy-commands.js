const fs = require('fs');

const path = require('path');

const { REST, Routes } = require('discord.js');

// ✅ FINAL BOSS MODE IDs

const clientId = '1385521602330099775'; // Bot / App ID

const guildId = '1333324217839779890';  // Server ID

const token = 'MTM4NTUyMTYwMjMzMDA5OTc3NQ.GWQUaZ.8lB0A9q4G2EJepd_VNjG2S--BpVkXG61KEcyjE';    // Replace this with your real token

const commands = [];

const commandsPath = path.join(__dirname, 'commands');

const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {

  const filePath = path.join(commandsPath, file);

  const command = require(filePath);

  if ('data' in command && 'execute' in command) {

    commands.push(command.data.toJSON());

  } else {

    console.log(`⚠️ Skipping invalid command: ${file}`);

  }

}

const rest = new REST({ version: '10' }).setToken(token);

(async () => {

  try {

    console.log('🧼 Clearing ALL guild slash commands...');

    await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: [] });

    console.log('📡 Re-registering valid commands...');

    await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });

    console.log('✅ Done! Slash commands updated cleanly.');

    console.log('📃 Active commands:', commands.map(c => c.name).join(', '));

  } catch (error) {

    console.error('❌ Error during deploy:', error);

  }

})();