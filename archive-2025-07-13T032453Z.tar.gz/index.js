// === 1. IMPORTS ===

const { Client, GatewayIntentBits, Collection } = require('discord.js');

const fs = require('fs');

const path = require('path');

// === 2. CLIENT SETUP ===

const client = new Client({

  intents: [

    GatewayIntentBits.Guilds,

    GatewayIntentBits.GuildMessages,

    GatewayIntentBits.MessageContent

  ]

});

// === 3. COMMAND HANDLER ===

client.commands = new Collection();

const commandsPath = path.join(__dirname, 'commands');

const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {

  const filePath = path.join(commandsPath, file);

  const command = require(filePath);

  if ('data' in command && 'execute' in command) {

    client.commands.set(command.data.name, command);

    console.log(`✅ Loaded command: ${command.data.name}`);

  } else {

    console.log(`⚠️ Command at ${filePath} is missing "data" or "execute" property.`);

  }

}

// === 4. READY EVENT ===

client.once('ready', () => {

  console.log(`🤖 Logged in as ${client.user.tag}`);

  client.user.setPresence({

    activities: [{

      name: 'Made by BasuXKrishna - Coding never fails',

      type: 0

    }],

    status: 'online'

  });

});

// === 5. INTERACTION HANDLER ===

client.on('interactionCreate', async interaction => {

  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);

  if (!command) {

    console.error(`No command matching ${interaction.commandName} was found.`);

    return;

  }

  try {

    await command.execute(interaction);

  } catch (error) {

    console.error(`❌ Error executing ${interaction.commandName}:`, error);

    const reply = {

      content: 'There was an error while executing this command!',

      ephemeral: true

    };

    if (interaction.replied || interaction.deferred) {

      await interaction.followUp(reply);

    } else {

      await interaction.reply(reply);

    }

  }

});

// === 6. LOGIN ===

// 🔐 Replace this with your token directly if not using .env

client.login('MTM4NTUyMTYwMjMzMDA5OTc3NQ.GWQUaZ.8lB0A9q4G2EJepd_VNjG2S--BpVkXG61KEcyjE');